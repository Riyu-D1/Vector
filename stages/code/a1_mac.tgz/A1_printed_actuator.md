# A1 — printed 40:1 cycloid actuator module (Tarot 4008), CAD + gates + renders + test sheet
> Before you start: you already read `~/Vector/ARM_KNUCKLE_V5.md`. Rules 0.1–0.10 apply to every step, EXCEPT these three overrides for A1 only: branch = `arm-actuator2` (not arm-knuckle), work dir = `~/Vector-wt/act2` (not knuckle), tag = `act-1-done`.
> Work dir: `~/Vector-wt/act2`. `export PY=/Users/deepakdiwan/soma/.venv/bin/python` first in every new shell. Use `/usr/bin/git` only.
> "Expected" = output must match. If not: re-run once, then do the "If not" line.

**Goal:** one 3D-printed single-disc cycloid actuator module that bolts into the reBot-style arm: Tarot 4008 330KV motor, 40:1 (fallback 50:1), Ø57 x 54.6 mm, STEP + STL for every printed part, all gates PASS, 6 renders, BOM + bench test sheet for Riyansh.
**Why:** bought actuators are too expensive. Riyansh wants a slim printed hybrid actuator he can print on his Bambu A1 and test this week. The design is DONE and tested; your job is to copy it in exactly, run it, prove the gates, render, document, commit. Do NOT redesign anything.
**Branch:** `arm-actuator2` (new, from `arm-knuckle` @ 9a55485 or later). **Tag to create:** `act-1-done`.
**Inputs (read-only, never edit):** `~/Vector/stages/code/act2/` (ap.py, cyclo.py, parts.py, build_act.py, check_act.py, render_act.py, a1_render_list.txt, TEST.md, .gitignore), `cad/knuckle/gate.py` (used as a library and CLI), `cad/knuckle/render_blend.py` (render_act.py is a copy of it with one number changed).
**Do not touch:** anything in `cad/knuckle/`, `docs/STATUS-knuckle.md`, branch `arm-knuckle`, any other worktree.

## Fixed design facts (for STATUS and questions; do not change)
| Item | Value | Tag |
|---|---|---|
| Housing OD / length | 57.0 / 54.6 mm (limit ≤ 55) | [S] OD from reBot joint, length [D] |
| Back face | 6 x M3 pilot Ø2.8, PCD 50, at 0+60k°, 6.5 deep; pilot boss Ø37.7 x 2 | [S] reBot 02_Motor_Back_Spacer |
| Output face | 6 x M3 heat-set Ø4.6 x 5 on PCD 27 at 30+60k°; 3 x Ø4 pin holes on PCD 24 at 60/180/300°, 4 deep; centre Ø14 | [S] reBot 02_Motor_Front_Spacer |
| Motor | Tarot 4008 330KV: Ø44.5 x 22, shaft 4, base holes 19/25 mm | [S] |
| Cam-to-bell screws | 2 x M3 slots r 5.0–6.5 at 90/270° | [U] measure the bell |
| Ring pins | 41 x Ø3 x 10 dowels on R 22.0 (50:1: 51 x Ø2.5) | [D] |
| Eccentricity e | 0.4 (50:1: 0.3), profile clearance 0.15 | [D] |
| Output pins | 6 x Ø2 x 12 on R 16.7; disc holes Ø(2 + 2e + 0.3) | [D] |
| Bearings | 2 x 6704 (20x27x4) in disc; 1 x 6707 (35x44x5) output | [S] ISO sizes |
| Encoder | AS5600 pocket 24x24 at back, floor z 0.6, Ø10 hole; magnet 6x2.5 | [U] board size |
| ESC | B-G431B-ESC1 30x41: goes ON THE LINK, not in the actuator (diag 50.8 > motor bore 45.1) | [S] |
| Wires | Ø6 hole at r 15.5, 45°, inside the pilot boss, slot to the motor bore z 4..7 | [D] |
| Print | Bambu A1, min wall 1.6, hole tolerance 0.15, running clearance 0.3 | [D] |

Disc profile (in cyclo.py, numpy only). R = ring-pin circle radius, rp = pin radius, e = eccentricity, N = number of ring pins (= ratio + 1), lobes = N − 1, d = 0.15, t = 0..2π:
`psi = atan2(sin((1−N)t), R/(e·N) − cos((1−N)t))`
`x = R·cos t − (rp+d)·cos(t+psi) − e·cos(N·t)`
`y = −R·sin t + (rp+d)·sin(t+psi) + e·sin(N·t)`
Clearance check: disc centre at e·(cos θ, sin θ), disc rotated −θ/lobes, θ sampled 360 times over one motor turn; gap between the disc outline and every pin circle must be ≥ 0.1 mm.

## Steps
1. **Worktree.** Command: `cd ~/Vector-wt/act2 && /usr/bin/git branch --show-current && /usr/bin/git log --oneline -1 && ls cad/knuckle/gate.py cad/knuckle/render_blend.py`
   Expected: `arm-actuator2`, a hash line, both paths printed.
   If not: `/usr/bin/git -C ~/Vector-wt/knuckle worktree add -b arm-actuator2 ~/Vector-wt/act2 arm-knuckle` (if the branch already exists: same without `-b`), then re-run. If still wrong: `BLOCKED: worktree`, STOP.
2. **Copy code verbatim.** Command: `mkdir -p cad/act2 && cp ~/Vector/stages/code/act2/{ap.py,cyclo.py,parts.py,build_act.py,check_act.py,render_act.py,TEST.md,.gitignore} cad/act2/ && cp ~/Vector/stages/code/act2/a1_render_list.txt cad/act2/render_list.txt && cd cad/act2 && ls -a && cat .gitignore`
   Expected: the 9 files listed; .gitignore = `out/`, `__pycache__/`, `*.stl`, `*.step`.
   If not: repeat the cp once. Do NOT retype or "improve" the code. Do NOT edit any number.
3. **NOTICE.** Create `cad/act2/NOTICE.md` with exactly:
   `Interface dimensions (back PCD50 6xM3, front PCD27 6xM3 + 3xØ4 on PCD24, OD 57) measured from the open-source reBot-DevArm (Seeed Studio) STEP files. Cycloid, housing and all other geometry are original to this repo.`
4. **Build.** Command (in `cad/act2`): `$PY build_act.py 2>&1 | grep -v -i warn`  (≈ 35–60 s)
   Expected (exactly these 9 lines; volumes may differ by ±0.1):
   ```
   act_body: bbox=(-28.5, 28.5, -28.5, 28.5, -2.0, 40.4) vol=47.5
   act_cam: bbox=(-18.0, 18.0, -18.0, 18.0, 29.0, 39.4) vol=3.8
   act_disc: bbox=(-20.29, 21.09, -20.69, 20.69, 31.4, 39.4) vol=5.4
   act_out: bbox=(-20.0, 20.0, -20.0, 20.0, 39.8, 52.6) vol=10.0
   act_cap: bbox=(-28.5, 28.5, -28.5, 28.5, 40.4, 52.2) vol=13.1
   buy_motor: bbox=(-22.25, 22.25, -22.25, 22.25, 7.0, 29.0) vol=34.2
   buy_ringpins: bbox=(-23.44, 23.5, -23.48, 23.48, 30.4, 40.4) vol=2.9
   buy_outpins: bbox=(-17.7, 17.7, -15.46, 15.46, 31.8, 43.8) vol=0.2
   buy_bearings: bbox=(-22.0, 22.0, -22.0, 22.0, 31.4, 50.4) vol=4.9
   ```
   Then `ls out/` → 9 `.stl` + 5 `.step` (act_body, act_cam, act_disc, act_out, act_cap). act_disc.step is ~9 MB; that is normal.
   If not: `diff -r ~/Vector/stages/code/act2 .` (ignore out/, NOTICE.md, render_list.txt) and re-copy any differing file; re-run. Still wrong → `BLOCKED: build`, paste output in STATUS, STOP.
5. **Actuator check** (cycloid clearance, output-pin clearance, length, OD, ESC note, body watertight + min wall, body interference). Command: `$PY check_act.py; echo rc=$?`  (≈ 10 s)
   Expected lines include: `CYCLO: ratio 40:1 min disc-pin clearance 0.128 mm (need >= 0.100) PASS`, `OUTPIN: ... 0.150 ... PASS`, `LENGTH: 54.6 mm (need <= 55.0) PASS`, `OD: 57.0 mm (need <= 57.0) PASS`, the `ESC: ... on the link ...` line, `BODY_WATERTIGHT: watertight=True PASS`, `BODY_MINWALL: 2.12 mm ... PASS`, 8 `INTERF act_body x ...` lines each PASS, last line `CHECK PASS`, `rc=0`.
   Note: the body min wall is measured outside the ring-pin groove band because the 0.3–0.6 mm ribs between Ø3 grooves are intentional (the steel pins carry the load). This is the ONLY gate exception; write it in STATUS.
   If not: re-copy, rebuild once. Still FAIL → `BLOCKED: check`, STOP. Do not tune numbers.
6. **Gate** (watertight, min wall ≥ 1.6, size, interference between all other parts). Command: `$PY ../knuckle/gate.py out/act_cam.stl out/act_disc.stl out/act_out.stl out/act_cap.stl out/buy_*.stl; echo rc=$?`  (≈ 5–10 s)
   Expected: 8 part lines ending `OK` (minwall cam 1.79, disc 1.74, out 1.82, cap 1.79), no `FAIL`, last line `GATE PASS`, `rc=0`.
   Do NOT add `out/act_body.stl` to this command (gate.py runs out of memory on the body; step 5 covers it).
   If not: `BLOCKED: gate`, paste the FAIL lines, STOP.
7. **50:1 fallback check** (proves the fallback works; do not keep its files). Command: `ACT_RATIO=50 $PY build_act.py 2>&1 | grep act_disc && ACT_RATIO=50 $PY check_act.py | grep -E "CYCLO|BODY_MINWALL|CHECK"`
   Expected: `act_disc: bbox=(-20.56, 21.16, -20.9, 20.9, 31.4, 39.4) vol=5.7`, `CYCLO: ratio 50:1 min disc-pin clearance 0.14x mm ... PASS`, `BODY_MINWALL: 2.08 ... PASS`, `CHECK PASS`.
   Then rebuild 40:1: `$PY build_act.py 2>&1 | grep act_disc` → the 40:1 act_disc line from step 4.
   If not: record `50:1 fallback FAIL` in STATUS (not a blocker), rebuild 40:1, continue.
8. **Renders.** Command: `mkdir -p renders out/renders && cp render_list.txt out/renders/a1.txt && /usr/local/bin/blender -b -P render_act.py -- renders/a1 out/renders/a1.txt 2>&1 | grep WROTE && ls -la renders`  (≈ 10 s)
   Expected: 6 `WROTE renders/a1_{frontiso,backiso,side,top,front,cutaway}.png`, each ≤ 1.5 MB.
   Look at every PNG (open it). Write one line per view in STATUS. Pass: whole module in frame, nothing floating; cutaway shows motor (grey), cam (yellow), disc (blue) inside the ring pins, carrier (orange), bearing rings.
   If not framed: do NOT edit render_act.py; record it under Questions.
9. **Test sheet.** `TEST.md` (copied in step 2) is the BOM + print table + spin, torque (100 mm lever + kitchen scale) and backlash tests. Command: `grep -c "^## " TEST.md` → `7`. Do not edit it.

## Gate before commit
Step 4 = 9 lines; step 5 `CHECK PASS`; step 6 `GATE PASS`; 6 `WROTE`. `/usr/bin/git status --short` shows ONLY: `cad/act2/{.gitignore,ap.py,cyclo.py,parts.py,build_act.py,check_act.py,render_act.py,render_list.txt,TEST.md,NOTICE.md}`, `cad/act2/renders/` (6 png), `docs/STATUS-act2.md`.

## Status + commit (always the last steps)
S.1 Create `docs/STATUS-act2.md` with a section `## A1 — <date> — PASS or FAIL` containing: the 9 build lines; the full step 5 and step 6 outputs; the step 7 lines; one line per render view; the gate exception (pin-groove ribs); Files added; Questions for Riyansh (copy these): (1) measure the bell-top screw radius/thread (BELL_SCREW_R [U]); (2) measure motor base thread depth (M3 x 8 assumed) [U]; (3) confirm AS5600 board size ≤ 24x24 [U]; (4) cap M2 heads sit proud of the cap face; OK with the link?; (5) print order: one act_disc + body ring first to check dowel/bearing fits.
S.2 `/usr/bin/git status --short` — only the files above. NO `out/`, NO `.stl`, NO `.step`, NO `__pycache__`, nothing under `cad/knuckle/`.
S.3 `/usr/bin/git add -A cad/act2 docs/STATUS-act2.md && /usr/bin/git commit -m "act 1: printed cycloid actuator module (40:1, Tarot 4008)"`
   Expected: `[arm-actuator2 <hash>] act 1: printed cycloid actuator module (40:1, Tarot 4008)`
S.4 `/usr/bin/git tag act-1-done && /usr/bin/git push -u origin arm-actuator2 && /usr/bin/git push origin act-1-done` (if rejected: `/usr/bin/git pull --ff-only origin arm-actuator2` once, push again; else `BLOCKED: push`).
S.5 STOP. Do not start another stage. Do not merge into arm-knuckle.
