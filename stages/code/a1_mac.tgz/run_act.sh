#!/bin/zsh
# Launch Devin on the A1 printed-actuator brief in worktree ~/Vector-wt/act2 (branch arm-actuator2).
source ~/.zshrc
WT=~/Vector-wt/act2
if [ ! -d "$WT" ]; then
  if /usr/bin/git -C ~/Vector-wt/knuckle show-ref --verify --quiet refs/heads/arm-actuator2; then
    /usr/bin/git -C ~/Vector-wt/knuckle worktree add "$WT" arm-actuator2 || exit 1
  else
    /usr/bin/git -C ~/Vector-wt/knuckle worktree add -b arm-actuator2 "$WT" arm-knuckle || exit 1
  fi
fi
cd "$WT" || exit 1
[ "$(/usr/bin/git branch --show-current)" = "arm-actuator2" ] || { echo "wrong branch in $WT"; exit 1; }
P=~/Vector/stages/.prompt_A1.txt
echo 'Read ~/Vector/ARM_KNUCKLE_V5.md rules 0.1-0.10 then do ~/Vector/stages/A1_printed_actuator.md exactly; stop when the gate passes and the commit is pushed.' > "$P"
devin --permission-mode dangerous -- "$(cat "$P")"
