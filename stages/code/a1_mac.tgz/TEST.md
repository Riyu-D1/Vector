# A1 printed cycloid actuator — BOM, print settings, bench tests (for Riyansh)
Module: one Tarot 4008 330KV + printed single-disc cycloid, 40:1 (fallback 50:1). Ø57 x 54.6 mm.
Numbers come from `ap.py`. [S] = sourced, [U] = unverified (measure before trusting).

## BOM (one module)
| # | Part | Qty | Note |
|---|------|-----|------|
| 1 | Tarot 4008 330KV motor (TL2955) | 1 | Ø44.5 x 22, 4 mm shaft, 85 g [S] |
| 2 | Steel dowel pin Ø3 x 10 (ring pins) | 41 | 50:1 fallback: Ø2.5 x 10, qty 51 |
| 3 | Steel dowel pin Ø2 x 12 (output pins) | 6 | pressed into carrier |
| 4 | Bearing 6704 (20x27x4) | 2 | stacked in the disc |
| 5 | Bearing 6707 (35x44x5) | 1 | output bearing in the cap |
| 6 | M3 x 8 button head | 4 | motor base, from the back, through slots [U] thread depth |
| 7 | M3 x 10 (or bell screws supplied with motor) | 2 | cam to motor bell [U] hole radius |
| 8 | M2 x 16 socket head | 6 | cap to body (heads stay proud of cap face) |
| 9 | M3 heat-set insert, Ø4.6 hole, 5 long | 6 | output face, PCD27 |
| 10 | M3 screws for link plate (length per link) | 6 | back face PCD50, 6.5 deep pilots |
| 11 | AS5600 board (~23x23) + diametric magnet 6x2.5 | 1 | back pocket 24x24 [U] board size |
| 12 | B-G431B-ESC1 (30x41) | 1 | mounts ON THE LINK, not in the actuator (diag 50.8 > bore 45.1) |
| 13 | PTFE/lithium grease | - | ring pins + disc lobes |

## Print (Bambu A1, 0.4 nozzle, PETG or PLA+, 0.16 layer, 4 walls, 40% gyroid)
| File | Orientation | Supports |
|------|-------------|----------|
| act_body.stl | back boss DOWN on the plate | none needed except encoder pocket bridge (tree, buildplate only) |
| act_disc.stl | flat | none |
| act_cam.stl | hub (big Ø36) DOWN | none |
| act_out.stl | carrier (Ø40) DOWN | none |
| act_cap.stl | front face DOWN | none |
Print one `act_disc` first and check a Ø3 dowel slides freely in a groove (body) and the 6704 presses into the disc. If too tight: Bambu Studio "X-Y hole compensation" +0.05 and reprint.

## Assembly order
1. Press 41 ring pins into body grooves (pins stand z 30.4..40.4). 2. Motor into bore, 4 x M3 from the back through the slots; centre it with 0.3 mm shims/paper all round, tighten, remove shims. 3. Glue magnet on the shaft end, AS5600 into the back pocket, chip facing the magnet (~2 mm gap [U]). 4. Cam onto the bell with 2 screws. 5. Two 6704 into the disc, disc onto cam journal, grease lobes. 6. Press 6 output pins into the carrier, 6707 onto the output hub, drop carrier so pins enter disc holes. 7. Cap on, 6 x M2, snug, not tight. Wires exit the Ø6 hole at 45° inside the pilot boss.

## Test 1 — spin (no load)
Hand-turn the output first: must turn the motor smoothly with no tight spot over 1 full output turn (40 motor turns). Then ESC open-loop or velocity mode at 300 then 1000 rpm motor for 60 s each. Record: current (A), noise, any knock per output turn. PASS: no binding, current < 1.0 A at 1000 rpm, housing < 40 °C after 2 min.

## Test 2 — torque (lever arm + kitchen scale)
Bolt the back face to a board. Bolt a 100 mm lever (stiff bar, hole-to-hole 100 mm) to the output face. Lever tip presses straight down on a kitchen scale (zeroed with the lever resting on it). Step the motor current limit up 1 A at a time (1, 2, 3 ... 10 A), hold 2 s each, read kg.
Torque (N·m) = kg x 9.81 x 0.100. Expected ideal ≈ Kt x A x 40, Kt ≈ 0.029 N·m/A [U] -> ≈1.15 N·m per A x efficiency.
Record the table: A | kg | N·m | efficiency = measured/ideal. STOP the step-up at the first click, creak, or if a pin walks out. PASS target: ≥ 3 N·m (3.06 kg at 100 mm) without damage.

## Test 3 — backlash
Lock the motor (power on, position hold; or hold the bell with the ESC off and a screw jammed in a slot). Lever 100 mm on the output, dial gauge or a ruler at the tip. Push the tip each way with ~0.5 kg (scale). Backlash (deg) = tip travel (mm) / 100 x 57.3. Also read it from the AS5600 (motor side) vs output angle if available. PASS: < 1.0° (printed target), record value.

## Results table (fill in)
| Date | Ratio | Material | Spin PASS? | Max N·m | Backlash ° | Notes |
|------|-------|----------|------------|---------|------------|-------|
